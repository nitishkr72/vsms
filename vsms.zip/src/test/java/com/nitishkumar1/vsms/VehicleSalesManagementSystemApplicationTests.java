package com.nitishkumar1.vsms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleSalesManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
