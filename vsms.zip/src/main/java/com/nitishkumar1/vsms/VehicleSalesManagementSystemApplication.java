package com.nitishkumar1.vsms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleSalesManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleSalesManagementSystemApplication.class, args);
	}

}
