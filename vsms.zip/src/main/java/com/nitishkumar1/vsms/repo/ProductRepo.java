package com.nitishkumar1.vsms.repo;

import com.nitishkumar1.vsms.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepo extends JpaRepository<Product, Integer> {
}
