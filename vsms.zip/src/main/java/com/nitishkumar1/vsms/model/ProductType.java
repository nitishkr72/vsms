package com.nitishkumar1.vsms.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "product_type")
public class ProductType implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "type_id")
    private int typeID;

    @Column(name = "type_value")
    private int typeValue;

    @Column(name = "name")
    private String name;
//
//    @OneToMany(mappedBy = "ProductType", cascade = { CascadeType.DETACH, CascadeType.MERGE,
//                CascadeType.PERSIST, CascadeType.REFRESH})
//    private List<Product> productList;

//    @OneToMany(mappedBy = "ProductType")
//    private List<Product> products;

    public ProductType() {
    }

    public ProductType(int typeValue, String name) {
        this.typeValue = typeValue;
        this.name = name;
    }

    public int getTypeValue() {
        return typeValue;
    }

    public void setTypeValue(int typeValue) {
        this.typeValue = typeValue;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ProductType{" +
                "typeValue=" + typeValue +
                ", name='" + name + '\'' +
                '}';
    }
}
