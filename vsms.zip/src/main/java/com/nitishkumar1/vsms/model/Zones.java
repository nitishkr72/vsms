package com.nitishkumar1.vsms.model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "zones")
public class Zones implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "zone_id")
    private int zoneId;

    @Column(name = "name")
    private String name;

    @Column(name = "target_monthly_quota")
    private long targetMonthlyQuota;

    @OneToMany(mappedBy = "zone",cascade = {CascadeType.PERSIST, CascadeType.DETACH,
                CascadeType.MERGE, CascadeType.REFRESH})
    private List<Employee> employeeList;

    public Zones() {
    }

    public Zones(String name, long targetMonthlyQuota) {
        this.name = name;
        this.targetMonthlyQuota = targetMonthlyQuota;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getTargetMonthlyQuota() {
        return targetMonthlyQuota;
    }

    public void setTargetMonthlyQuota(long targetMonthlyQuota) {
        this.targetMonthlyQuota = targetMonthlyQuota;
    }

    @Override
    public String toString() {
        return "Zones{" +
                "name='" + name + '\'' +
                ", targetMonthlyQuota=" + targetMonthlyQuota +
                '}';
    }
}
