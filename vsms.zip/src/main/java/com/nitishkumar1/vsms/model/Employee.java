package com.nitishkumar1.vsms.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "employee")
public class Employee implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_id")
    private int employeeId;

    @Column(name = "name")
    private String name;

    @Column(name = "manager_Id")
    private int managerId;

    @Column(name = "level")
    private int level;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.DETACH,
                                CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "zone_id")
    private Zones zone;

    @Column(name = "email")
    private String email;

    @Column(name = "phone_number")
    private long phoneNumber;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "password")
    private String password;

    public Employee() {
    }

    public Employee(int employeeId, String name, int managerId, int level, Zones zone, String email, long phoneNumber, String imageUrl, String password) {
        this.employeeId = employeeId;
        this.name = name;
        this.managerId = managerId;
        this.level = level;
        this.zone = zone;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.imageUrl = imageUrl;
        this.password = password;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getManagerId() {
        return managerId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Zones getZone() {
        return zone;
    }

    public void setZone(Zones zone) {
        this.zone = zone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", managerId=" + managerId +
                ", level=" + level +
                ", zone=" + zone +
                ", email='" + email + '\'' +
                ", phoneNumber=" + phoneNumber +
                ", imageUrl='" + imageUrl + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
