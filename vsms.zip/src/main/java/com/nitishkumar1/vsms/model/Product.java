package com.nitishkumar1.vsms.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "product")
public class Product implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private int productId;
//
    @Column(name = "cost")
    private int cost;
//
////    @ManyToOne
////    @JoinColumn(name = "type_id")
////    private ProductType productType;
//
//    @Column(name = "color")
//    private String color;
//
//    @Column(name = "current_discount")
//    private int currentDiscount;
//
//    @Column(name = "name", unique = true, nullable = false)
//    private String name;
//
//    @Column(name = "description")
//    private String description;
//
//    @Column(name = "image_url")
//    private String imageUrl;

    public Product() {
    }

    public Product(int cost) {
        this.cost = cost;
//        this.productType = productType;
//        this.color = color;
//        this.currentDiscount = currentDiscount;
//        this.name = name;
//        this.description = description;
//        this.imageUrl = imageUrl;
    }

//    public Product(int cost, ProductType productType, String color, int currentDiscount, String name, String description, String imageUrl) {
//        this.cost = cost;
//        this.productType = productType;
//        this.color = color;
//        this.currentDiscount = currentDiscount;
//        this.name = name;
//        this.description = description;
//        this.imageUrl = imageUrl;
//    }
//
//
    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

//    public ProductType getProductType() {
//        return productType;
//    }
//
//    public void setProductType(ProductType productType) {
//        this.productType = productType;
//    }
//
//    public String getColor() {
//        return color;
//    }
//
//    public void setColor(String color) {
//        this.color = color;
//    }
//
//    public int getCurrentDiscount() {
//        return currentDiscount;
//    }
//
//    public void setCurrentDiscount(int currentDiscount) {
//        this.currentDiscount = currentDiscount;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    public String getImageUrl() {
//        return imageUrl;
//    }
//
//    public void setImageUrl(String imageUrl) {
//        this.imageUrl = imageUrl;
//    }

    @Override
    public String toString() {
        return "Product{" +
                "cost=" + cost; //+
//                ", productType=" + productType +
//                ", color='" + color + '\'' +
//                ", currentDiscount=" + currentDiscount +
//                ", name='" + name + '\'' +
//                ", description='" + description + '\'' +
//                ", imageUrl='" + imageUrl + '\'' +
//                '}';
    }
}
