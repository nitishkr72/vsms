package com.nitishkumar1.vsms.service;

import com.nitishkumar1.vsms.model.Employee;
import com.nitishkumar1.vsms.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    private EmployeeRepo employeeRepo;

    @Autowired
    public EmployeeService(EmployeeRepo employeeRepo) {
        this.employeeRepo = employeeRepo;
    }

    /*
     *
     *   Utility function defined here
     *
     */

    public List<Employee> findAllEmployee() {
        return employeeRepo.findAll();
    }
}
